# ♟ Shashka Arena — Telegram Mini App + Bot

Rus shashkasi o'yini. Hamma narsa (foydalanuvchi, ball, pul, chempionat, e'lon)
Telegram bot orqali boshqariladi. O'yin ichida hech qanday admin panel yo'q.

## Tarkib

| Fayl | Vazifasi |
|---|---|
| `bot.py` | Telegram bot + admin panel + Mini App serveri (bir jarayonda) |
| `database.py` | PostgreSQL: foydalanuvchi, ball, to'lov, turnir, e'lon |
| `webapp_api.py` | Mini App API (`initData` imzosi tekshiriladi) |
| `tolov_api.py` | Avtomatik to'lov — TolovAPI orqali (tavsiya etiladi) |
| `humo_listener.py` | Avtomatik to'lov — HUMOcard userbot orqali |
| `generate_session.py` | HUMO uchun session string olish |
| `webapp/index.html` | O'yinning o'zi (Mini App) |

## 1. O'rnatish

```bash
pip install -r requirements.txt
cp .env.example .env     # va qiymatlarni to'ldiring
python bot.py
```

Bitta jarayon ikkita ishni bajaradi: botni ham, Mini App serverini ham (`PORT`).

## 2. BotFather sozlamasi

1. `/newbot` → token oling → `BOT_TOKEN`
2. `/setmenubutton` → **Web App** → `WEBAPP_URL` ni kiriting (domen **HTTPS** bo'lishi shart)
3. `/setdescription`, `/setuserpic` — ixtiyoriy

`WEBAPP_URL` — shu serverning `/` manzili. Masalan Railway'da
`https://shashka-production.up.railway.app`.

## 3. Admin panel

Faqat **botda**: `/admin` (faqat `ADMIN_ID` dagi ID lar ko'radi).
O'yin ichida admin paneli **yo'q** — mijoz tomonida hech narsa ko'rinmaydi.

Admin nima qila oladi:

- **📊 Statistika** — o'yinchilar, o'yinlar, tushum (bugun/jami), muomaladagi ball
- **👥 O'yinchilar** — ID/ism/@username bo'yicha qidirish, ball va pul berish/olish,
  bloklash, shaxsiy xabar yuborish, tranzaksiya tarixi
- **💎 Ball paketlari** — paket qo'shish, narx/ball/nom/yorliqni o'zgartirish, yoqish-o'chirish
- **🎮 O'yin sozlamasi** — g'alaba mukofotlari, yordam narxlari (undo/damka/2xod/maslahat),
  dizayn narxlari, ELO, referal bonusi, yangi o'yinchiga sovg'a, kunlik limit
- **🏆 Chempionat** — bitta xabar bilan turnir yaratish, TOPni ko'rish,
  yakunlash → g'oliblarga **pul avtomatik hisoblanadi** + hammaga e'lon
- **📣 E'lonlar** — Mini App bosh sahifasida ko'zga tashlanadigan joyda chiqadi
  (`prize` turi — oltin rangli, yaltiraydigan banner)
- **📨 Xabar yuborish** — barcha o'yinchilarga
- **💳 To'lov sozlamasi** — karta, avto to'lov, TolovAPI kalitlari, muddat
- **🔧 Texnik rejim** — botni vaqtincha yopish

### Chempionat yaratish

```
Haftalik chempionat | Eng ko'p g'alaba qozongan 3 kishi pul oladi | 7 | 1:500000, 2:300000, 3:150000
```

Tugagach avtomatik yakunlanadi (`tournament_watcher` har 2 daqiqada tekshiradi),
g'oliblarga pul hisobiga tushadi, hammaga xabar ketadi. To'lovlar ro'yxati:
**Chempionat → 💸 To'lovlar**.

### E'lon yaratish

```
Haftalik chempionat | 1-o'rin 500 000 so'm! Yakshanbagacha | 🏆 | prize
```

turi: `prize` (oltin), `info` (oddiy), `warning` (qizil).

## 4. Pul oqimi (ball sotish)

```
Karta orqali to'ldirish  →  SO'M balans  →  ball paketi  →  BALL  →  o'yin ichida sarflanadi
```

- **Avtomatik to'lov**: foydalanuvchi summani kiritadi, bot unga **noyob summa** beradi
  (masalan 20 000 emas, 20 037). Shu summa kelganda balans 1–2 daqiqada o'zi to'ladi.
- **Qo'lda**: chek rasmi → adminga tugmali xabar → tasdiq.

Ikkalasi ham bir vaqtda ishlaydi. Avtomatik to'lov uchun ikki yo'l bor:

1. **TolovAPI** (oson) — `/admin → To'lov sozlamasi` da `shop_id` va `shop_key` ni kiriting.
2. **HUMOcard userbot** — `python3 generate_session.py` → chiqqan session stringni `.env` ga
   qo'ying. Faqat **bitta** serverda ishlating.

`FOR UPDATE SKIP LOCKED` tufayli bitta to'lov ikki marta hisoblanmaydi.

## 5. Xavfsizlik (anti-chit)

O'yin natijasi brauzerda emas, **serverda** hisoblanadi:

- foydalanuvchi `initData` HMAC imzosi bilan tanib olinadi — soxtalashtirib bo'lmaydi;
- ball/ELO mukofoti faqat `/api/game` ichida, server sozlamasidan olinadi;
- 15 soniyadan tez yoki 6 xoddan kam "g'alaba" — mukofot berilmaydi;
- kunlik mukofotli o'yin limiti bor (`daily_limit_bot`, standart 60);
- daqiqasiga 40 ta so'rovdan ko'pi bloklanadi.

## 6. O'yin ichidagi yangiliklar

- **18 ta taxta mavzusi** va **14 ta dona to'plami** (bir-biridan mustaqil — xohlagan
  kombinatsiya). 3 ta taxta va 2 ta to'plam bepul, qolgani ball evaziga ochiladi.
- Kirish animatsiyasi, donalarning uchib borishi, urilganda uchqun, konfetti, ovoz.
- Chempionat kartasi: jonli teskari sanoq, mukofot jamg'armasi, sizning o'rningiz.
- Admin e'lonlari bosh sahifada eng tepada.
- Telegram profili: ism va avatar avtomatik olinadi.
- Interaktiv qo'llanma + O'rganish markazi.
- Internet uzilsa — "mashq rejimi" da o'ynash davom etadi (ball hisoblanmaydi).

## 7. Deploy (Railway namunasi)

1. Repoga yuklang → **New Project → Deploy from GitHub**
2. **PostgreSQL** qo'shing → `DATABASE_URL` o'zi ulanadi
3. `Variables` ga `.env.example` dagi qiymatlarni kiriting
4. `Start command`: `python bot.py`
5. Domenni oling → `WEBAPP_URL` ga yozing → BotFather'da menu button qiling

VPS uchun: `nginx` + `certbot` bilan HTTPS qilib, `systemd` xizmat sifatida ishga tushiring.

## 8. Tez-tez so'raladigan

**Mini App "auth" xatosi bermoqda** — `BOT_TOKEN` server va bot uchun bir xil bo'lishi kerak,
va app faqat Telegram ichidan ochilishi lozim (brauzerda mashq rejimi ishlaydi).

**Ball paketlari ko'rinmayapti** — `/admin → Ball paketlari` da kamida bittasi 🟢 bo'lsin.

**Narxlarni o'zgartirdim, appda eskisi** — ilovani yopib qayta oching (`/api/init` qayta yuklanadi).
